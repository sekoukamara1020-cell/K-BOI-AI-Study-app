# K-BOI AI Study App

A responsive, static website starter for K-BOI AI Study App. It includes built-in sample lessons and quizzes, browser-local notes, a focus timer, and local progress counters.

## Files
- `index.html` — app structure
- `style.css` — responsive layout and styling
- `app.js` — lessons, quizzes, notes, timer, and progress logic
- `manifest.json` — installable web app metadata
- `service-worker.js` — basic offline caching
- `icons/icon.svg` — app icon

## Test locally
Open `index.html` in a modern browser to test the main interface. For install/offline behavior, serve the folder over HTTPS or localhost (service workers do not work from a normal `file://` URL).

## Publish with GitHub Pages
1. Create a GitHub repository named `k-boi-ai-study-app`.
2. Upload all files and the `icons` folder to the repository root.
3. Open repository **Settings → Pages**.
4. Under build and deployment, select **Deploy from a branch**, choose `main` and `/ (root)`, then save.
5. Wait for GitHub Pages to publish the site. Open the exact URL shown in Pages settings and test it on phone and computer.

## Before public release
- Replace the sample lessons/quizzes with reviewed educational content suitable for the intended grades.
- Add a real privacy policy and contact details that reflect the actual product and data handling.
- Test accessibility, mobile layout, offline behavior, and note storage.
- The “AI tutor” in this starter is not connected to a live AI model; it presents built-in sample lessons.
- Notes and progress are stored in local browser storage on each device. They do not sync.
- The service worker caches core files; after a deployment, consider changing the cache version in `service-worker.js`.
- For Google Play, build a proper Android package using a supported Trusted Web Activity or other appropriate approach, test it, and complete current Play Console requirements. A website link alone does not publish the app to Google Play.
